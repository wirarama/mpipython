from mpi4py import MPI

comm = MPI.COMM_WORLD
size = comm.Get_size()
rank = comm.Get_rank()

data = (rank+1)
data = comm.gather(data, root=0)
print("rank %d menerima %s" % (rank,data))
